

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Tambah ').$role); ?></div>

                <div class="card-body">
                    
                    <form action="/pengguna/add" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="role" value="<?php echo e($role); ?>">
                        <div class="form-group">
                          <label for="kodeMatkul">Nama</label>
                          <input type="text" class="form-control" id="kodeMatkul" placeholder="Masukkan Nama..." name="name">
                        </div>
                        <div class="form-group">
                          <label for="namaMatkul">Email</label>
                          <input type="text" class="form-control" id="namaMatkul" placeholder="Masukkan Email..." name="email">
                        </div>
                        <?php if($role == 'mahasiswa'): ?>    
                          <div class="form-group">
                            <label for="namaMatkul">Kode Mahasiswa</label>
                            <input type="text" class="form-control" id="namaMatkul" placeholder="Masukkan Kode Mahasiswa/NIM..." name="kode_mahasiswa">
                          </div>
                          <div class="form-group">
                            <label for="namaMatkul">Kelas</label>
                            <input type="text" class="form-control" id="namaMatkul" placeholder="Masukkan Kelas..." name="kelas">
                          </div>
                        <?php elseif($role == 'dosen'): ?>    
                          <div class="form-group">
                            <label for="namaMatkul">Kode Dosen</label>
                            <input type="text" class="form-control" id="namaMatkul" placeholder="Masukkan Kode Dosen..." name="kode_dosen">
                          </div>
                        <?php endif; ?>
                        <div class="form-group">
                          <label for="namaMatkul">Password</label>
                          <input type="password" class="form-control" id="namaMatkul" placeholder="Masukkan Password..." name="password">
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                      </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Daily\dev\Side Job\mentoring\Dzaky\mtrg-dzaky\resources\views/pengguna/add.blade.php ENDPATH**/ ?>