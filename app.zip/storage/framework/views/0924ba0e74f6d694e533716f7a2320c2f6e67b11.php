

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Data Transaksi')); ?></div>

                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <a href="/transaksi/add" type="button" class="btn btn-primary">Tambah</a>
                        <form action="/laporan/cetak" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                            <label for="kodeDosen">Dosen</label>
                            <select id="kodeDosen" class="form-control" name="kode_dosen">
                                <option value="">Semua Data</option>
                                <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->kode_dosen); ?>"><?php echo e($item->nama_dosen); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Cetak Laporan</button>
                        </form>
                    </div>
                    
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Mata Kuliah</th>
                            <th scope="col">Nama Dosen</th>
                            <th scope="col">Tahun Akademik</th>
                            <th scope="col">Semester</th>
                            <th scope="col">Kelas</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td><?php echo e($item->nama_matkul); ?></td>
                                    <td><?php echo e($item->nama_dosen); ?></td>
                                    <td><?php echo e($item->tahun_akademik); ?></td>
                                    <td><?php echo e($item->semester); ?></td>
                                    <td><?php echo e($item->kelas); ?></td>
                                    <td>
                                        <a href="/matkul/edit/<?php echo e($item->id); ?>" type="button" class="btn btn-warning">Edit</a>
                                        <a type="button" class="btn btn-danger" onclick="return confirm('Apakah kamu yakin?');" href="matkul/delete/<?php echo e($item->id); ?>">delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\,Daily\dev\Side Job\mentoring\Dzaky\mtrg-dzaky\resources\views/transaksi/index.blade.php ENDPATH**/ ?>