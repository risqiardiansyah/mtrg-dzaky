<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    <script>
        $('#myModal').on('shown.bs.modal', function () {
          $('#myInput').trigger('focus')
        })
    </script>
</head>
<body>
    <div id="app">
        <div class="container-fluid">
            <div class="row justify-content-start">
                <div class="col-md-8 p-5">
                    <p><?php echo e($detail_soal_now->desc_soal); ?></p>
                    <form action="/simpan_jawaban" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="index" value="<?php echo e($index); ?>">
                        <input type="hidden" name="tr_data_code" value="<?php echo e($tr_data_code); ?>">
                        <input type="hidden" name="data_jawaban_code" value="<?php echo e($data_jawaban_code); ?>">
                        <input type="hidden" name="tr_soal_code" value="<?php echo e($tr_soal_code); ?>">

                        <div class="input-group mt-2">
                            <div class="input-group-prepend w-100">
                                <div class="input-group-text">
                                    <input type="radio" id="option_a" name="jawaban" value="option_a" <?php echo e($detail_soal_now->jawaban == 'option_a' ? "checked" : ''); ?>>
                                    <label for="option_a"><?php echo e($detail_soal_now->option_a); ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="input-group mt-2">
                            <div class="input-group-prepend w-100">
                                <div class="input-group-text">
                                    <input type="radio" id="option_b" name="jawaban" value="option_b" <?php echo e($detail_soal_now->jawaban == 'option_b' ? "checked" : ''); ?>>
                                    <label for="option_b"><?php echo e($detail_soal_now->option_b); ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="input-group mt-2">
                            <div class="input-group-prepend w-100">
                                <div class="input-group-text">
                                    <input type="radio" id="option_c" name="jawaban" value="option_c" <?php echo e($detail_soal_now->jawaban == 'option_c' ? "checked" : ''); ?>>
                                    <label for="option_c"><?php echo e($detail_soal_now->option_c); ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="input-group mt-2">
                            <div class="input-group-prepend w-100">
                                <div class="input-group-text">
                                    <input type="radio" id="option_d" name="jawaban" value="option_d" <?php echo e($detail_soal_now->jawaban == 'option_d' ? "checked" : ''); ?>>
                                    <label for="option_d"><?php echo e($detail_soal_now->option_d); ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="input-group mt-2">
                            <div class="input-group-prepend w-100">
                                <div class="input-group-text">
                                    <input type="radio" id="option_e" name="jawaban" value="option_e" <?php echo e($detail_soal_now->jawaban == 'option_e' ? "checked" : ''); ?>>
                                    <label for="option_e"><?php echo e($detail_soal_now->option_e); ?></label>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success mt-3">
                            <?php echo e($detail_soal->jml_soal == $index + 1 ? "Selesaikan Ujian" : "Soal Selanjutnya"); ?>

                        </button>
                    </form>
                </div>

                <div class="col-md-4 border p-3">
                    <div class="container">
                        <div class="row justify-content-start">
                            <p>
                                <?php echo e($detail_soal->tipe_soal); ?> - <?php echo e($detail_soal->nama_ujian); ?> <br>
                                Dosen: <?php echo e($detail_soal->nama_dosen); ?> <br>
                                Mata Kuliah: <?php echo e($detail_soal->nama_matkul); ?>

                            </p>
                            <h5>Nomor Soal</h5>

                            <?php $__currentLoopData = $list_soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-1 border m-2 <?php echo e($soal->tr_soal_code == $tr_soal_code ? "bg-primary" : ($soal->terjawab ? "bg-warning" : '')); ?>">
                                    <a href="/kerjakan/<?php echo e($tr_data_code); ?>/<?php echo e($data_jawaban_code); ?>/<?php echo e($soal->tr_soal_code); ?>" class="text-black text-decoration-none">
                                        <div class="container">
                                            <div class="row pt-2">
                                                <?php echo e($key + 1); ?>

                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Daily\dev\Side Job\mentoring\Dzaky\mtrg-dzaky\resources\views/soal/kerjakan.blade.php ENDPATH**/ ?>