

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Edit Mata Kuliah')); ?></div>

                <div class="card-body">
                    
                    <form action="/matkul/edit" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="form-control" id="id" aria-describedby="emailHelp" name="id" value="<?php echo e($id); ?>">
                        <div class="form-group">
                          <label for="kodeMatkul">Kode Matkul</label>
                          <input type="text" class="form-control" id="kodeMatkul" aria-describedby="emailHelp" placeholder="Masukkan Kode Matkul..." name="kodeMatkul" value="<?php echo e($data->kode_matkul); ?>">
                        </div>
                        <div class="form-group">
                          <label for="namaMatkul">Nama Matkul</label>
                          <input type="text" class="form-control" id="namaMatkul" aria-describedby="emailHelp" placeholder="Masukkan Kode Matkul..." name="namaMatkul" value="<?php echo e($data->nama_matkul); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                      </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\,Daily\dev\Side Job\mentoring\Dzaky\mtrg-dzaky\resources\views/matkul/edit.blade.php ENDPATH**/ ?>