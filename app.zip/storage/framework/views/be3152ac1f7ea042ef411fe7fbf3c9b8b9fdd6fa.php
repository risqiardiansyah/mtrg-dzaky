

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-start">
        <div class="col-md-1"></div>
        <div class="col-md-11 justify-content-start">
            <div class="container">
                <div class="row justify-content-start">
                    <h1>List Ujian</h1>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($item->tipe_soal); ?></h5>
                                    <p class="card-text">
                                        <?php echo e($item->nama_ujian); ?> <br>
                                        Matkul : <?php echo e($item->nama_matkul); ?> <br>
                                        Dosen : <?php echo e($item->nama_dosen); ?> <br>
                                        Tahun : <?php echo e($item->tahun_akademik); ?> <br>
                                        Semester : <?php echo e($item->semester); ?> <br>
                                        Kelas : <?php echo e($item->kelas); ?> <br>
                                        Jml Soal : <?php echo e($item->jml_soal); ?> <br>

                                        <?php if($item->status_pengerjaan == 'finish'): ?>
                                            <b>Nilai : <?php echo e($item->nilai); ?></b>
                                        <?php endif; ?>
                                    </p>
                                    <?php if($item->status_pengerjaan == ''): ?>
                                        <form action="/kerjakan" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="tr_data_code" value="<?php echo e($item->tr_data_code); ?>">

                                            <button type="submit" class="btn btn-primary">Kerjakan</button>
                                        </form>
                                    <?php elseif($item->status_pengerjaan == 'progress'): ?>
                                        <a href="/kerjakan/<?php echo e($item->tr_data_code); ?>/<?php echo e($item->data_jawaban_code); ?>/<?php echo e($item->tr_soal_code); ?>" class="btn btn-success">
                                            Lanjut Mengerjakan
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-primary" disabled>Telah Dikerjakan</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Daily\dev\Side Job\mentoring\Dzaky\mtrg-dzaky\resources\views/soal/index_mahasiswa.blade.php ENDPATH**/ ?>